##############################################
Function CreateFile
{

  param
  (
    [Parameter(Mandatory = $true)]
    [String]$Folder,
    [Parameter(Mandatory = $true)]
    [String]$FileName
  )

  Try
  {
    New-Item $Folder\$FileName -ItemType file
    }
    Catch
     {
        Use-ErrorHandle -Message "Unable to log current details "
     }
}
##################################################
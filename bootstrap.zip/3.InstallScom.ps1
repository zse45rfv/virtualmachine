$DateStamp = get-date -Format yyyyMMddTHHmmss
$Folder = $env:ALLUSERSPROFILE + "\BootStrapInstallation\"
$File = "Scom.txt"
CreateFile -Folder $Folder -FileName $File
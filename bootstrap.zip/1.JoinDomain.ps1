$DateStamp = get-date -Format yyyyMMddTHHmmss
$Folder = $env:ALLUSERSPROFILE + "\BootStrapInstallation\"
$File = "JoinDomain.txt"
CreateFile -Folder $Folder -FileName $File